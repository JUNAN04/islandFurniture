document.write('\
<head>\
    <meta charset="utf-8">\
    <title>Island Furniture</title>\
    <link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.css">\
    <link rel="stylesheet" href="/vendor/font-awesome/css/font-awesome.css">\
    \
    <link rel="stylesheet" href="/css/theme.css">\
    <link rel="stylesheet" href="/css/theme-elements.css">\
    \
    <link rel="stylesheet" href="/css/theme-responsive.css" />\
    \
    <link rel="stylesheet" href="/css/skins/default.css">\
    \
    <script src="/vendor/jquery.js"></script>\
    <script src="/js/disableBack.js"></script>\
</head>');