class Supplier {
    constructor() { 
        this.id = null;
        this.address = null;
        this.contactNum = null;
        this.email = null;
        this.isDeleted = null;
        this.supplierName = null;
        this.countryId = null;
        this.regionalOfficeId = null;
    }
}
module.exports = Supplier;