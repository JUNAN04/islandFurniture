class SalesRecord_LineItem {
    constructor() { 
        this.salesRecordId = null;
        this.itemPurchasedId = null;
    }
}
module.exports = SalesRecord_LineItem;