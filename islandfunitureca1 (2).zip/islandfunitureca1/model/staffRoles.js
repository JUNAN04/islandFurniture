class StaffRoles {
    constructor() { 
        this.id = null;
        this.accessLevel = null;
        this.name = null;
    }
}
module.exports = StaffRoles;