class Warehouse {
    constructor() { 
        this.id = null;
        this.address = null;
        this.email = null;
        this.isDeleted = null;
        this.telephone = null;
        this.warehouseName = null;
        this.countryId = null;
        this.regionalOfficeId = null;
    }
}
module.exports = Warehouse;