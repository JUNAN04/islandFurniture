class RetailProduct {
    constructor() { 
        this.id = null;
        this.name = null;
        this.imageURL = null;
        this.sku = null;
        this.description = null;
        this.type = null;
        this.category = null;
        this.price = null;
        this.length = null;
        this.width = null;
        this.height = null;
    }
}
module.exports = RetailProduct;