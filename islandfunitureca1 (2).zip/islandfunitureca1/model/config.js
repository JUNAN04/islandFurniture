module.exports = {
    secret: 'secretKeyIslandFurniture'
};