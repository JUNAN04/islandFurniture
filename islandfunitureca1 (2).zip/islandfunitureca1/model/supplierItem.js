class SupplierItem {
    constructor() { 
        this.id = null;
        this.costprice = null;
        this.isDeleted = null;
        this.leadTime = null;
        this.lotSize = null;
        this.itemId = null;
        this.supplierId = null;
    }
}
module.exports = SupplierItem;